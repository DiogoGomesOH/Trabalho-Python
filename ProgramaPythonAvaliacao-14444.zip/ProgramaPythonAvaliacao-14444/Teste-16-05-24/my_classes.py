import my_connection as co
from tkinter import Toplevel, Label, Entry, Button, ttk, END, messagebox, StringVar
import tkinter as tk
import sqlite3
import datetime

class Produto:
    def __init__(self, nome, preco_base, iva, stock):
        self.nome = nome
        self.preco_base = preco_base
        self.iva = iva
        self.stock = stock

def clear_boxes(box1, *boxes):
    box1.delete(0,'end')
    for box in boxes:
        box.delete(0,'end')
    box1.focus_set()

# Função para registrar logs
def write_log(operation, product_id=None):
    with open("produto_log.txt", "a") as log_file:
        log_message = f"{datetime.datetime.now()}: {operation}"
        if product_id:
            log_message += f" - ID do Produto: {product_id}"
        log_file.write(log_message + "\n")


# Funcao para inserir o produto
def save_produto(nome, preco_base, iva, stock):
    novo_produto = Produto(nome, preco_base, iva, stock)
    sql = f'INSERT INTO {co.TABLE_NAME}(nome, preco_base, iva, stock) VALUES (?, ?, ?, ?)'
    co.cursor.execute(sql, (novo_produto.nome.get(), novo_produto.preco_base.get(), novo_produto.iva.get(), novo_produto.stock.get()))
    co.con.commit()
    clear_boxes(nome, preco_base, iva, stock)
    messagebox.showinfo("Sucesso", "Produto inserido com sucesso!")
    write_log("Produto inserido", novo_produto.nome.get())


# funcao para verificar se o id esta selecionado para apagar
def verify_selected_product_to_delete(tree):
    selected_items = tree.selection()
    if selected_items:
        index = selected_items[0]
        show_index_tree_and_delete(index, tree)
    else:
        messagebox.showwarning("Aviso", "Selecione um produto para apagar.")

# funcao para amostrar o index e apagar
def show_index_tree_and_delete(index, tree):
    x = tree.item(index,"values")
    y = x[0]
    sql = f'DELETE FROM {co.TABLE_NAME} WHERE nome = ?'
    co.cursor.execute(sql, (y,))
    tree.delete(index)
    co.con.commit()
    messagebox.showinfo("Sucesso", "Produto apagado com sucesso!")
    write_log("Produto apagado", y)


# funcao para verificar se o id esta selecionado para atualizar
def verify_selected_product_to_update(tree):
    selected_items = tree.selection()
    if selected_items:
        index = selected_items[0]
        produto_id = tree.item(index, 'text')
        show_update_form(produto_id)
    else:
        messagebox.showwarning("Aviso", "Selecione um produto para atualizar.")


# funcao para buscar as informacoes
def show_update_form(produto_id):
    co.cursor.execute(f"SELECT * FROM {co.TABLE_NAME} WHERE codigo = {produto_id}")
    produto = co.cursor.fetchone()
    update_form = update_produto_form(produto_id)
    update_form.my_name_text.insert(0, produto[1])
    update_form.my_preco_base_text.insert(0, produto[2])
    update_form.my_iva_text.insert(0, produto[3])
    update_form.my_stock_text.insert(0, produto[4])
    update_form.mainloop()



# class para inserir um novo produto
class new_produto_form(Toplevel):  
    def __init__(self):
        super().__init__()
        self.geometry('400x250')
        self.title('Novo Produto')
        
        my_name_label = Label(self, text="Nome", justify="left")
        my_name_text = Entry(self, width=62)
        my_preco_base_label = Label(self, text="Preco")
        my_preco_base_text = Entry(self, width=62)
        my_iva_label = Label(self, text="Iva")
        my_iva_text = Entry(self, width=62)
        my_stock_label = Label(self, text="Stock")
        my_stock_text = Entry(self, width=62)
        btn_insert = Button(self, text="Inserir novo produto", width=21, padx= 10, pady=5, command=lambda: save_produto(my_name_text, my_preco_base_text, my_iva_text, my_stock_text))
        btn_cancel = Button(self, text="Cancelar", width=21, padx= 10, pady=5, command=self.destroy)

        my_name_label.grid(row=0, column=0, padx=(10,0), sticky="W")
        my_name_text.grid(row=1, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        my_preco_base_label.grid(row=3, column=0, padx=(10,0), sticky="W")
        my_preco_base_text.grid(row=4, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        my_iva_label.grid(row=6, column=0, padx=(10,0), sticky="W")
        my_iva_text.grid(row=7, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        my_stock_label.grid(row=9, column=0, padx=(10,0), sticky="W")
        my_stock_text.grid(row=10, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        btn_insert.grid(row=12, column=0, padx=(10,0))
        btn_cancel.grid(row=12, column=1, padx=(10,0))



# class para ver, apagar, e atualizar os produtos
class produto_list_form(Toplevel):
    def __init__(self):
        super().__init__()
        self.geometry('600x400')
        self.title('Lista dos Produtos')

        self.order_by = StringVar()
        self.order_by.set("codigo")

        # Adicionando um combobox para selecionar a ordenação
        order_by_label = Label(self, text="Ordenar por:")
        order_by_combo = ttk.Combobox(self, textvariable=self.order_by, values=["codigo", "iva"], state="readonly")
        order_by_combo.bind("<<ComboboxSelected>>", lambda event: self.update_product_list(trv_list_produtos))

        title_label = Label(self, text="Lista dos Produtos", width=40, pady=10)
        trv_list_produtos = ttk.Treeview(self, columns=("nome", "preco", "iva", "stock", "valor_stock"))
        btn_delete = Button(self, text="Apagar Produto", width=30, pady=5, command=lambda: verify_selected_product_to_delete(trv_list_produtos))
        btn_update = Button(self, text="Atualizar Produto", width=30, pady=5, command=lambda: verify_selected_product_to_update(trv_list_produtos))

        trv_list_produtos.heading("#0", text="Codigo")
        trv_list_produtos.heading("nome", text="Nome")
        trv_list_produtos.heading("preco", text="Preco")
        trv_list_produtos.heading("iva", text="Iva")
        trv_list_produtos.heading("stock", text="Stock")
        trv_list_produtos.heading("valor_stock", text="Valor em Stock")

        trv_list_produtos.column("#0", width=50)
        trv_list_produtos.column("nome", width=150)
        trv_list_produtos.column("preco", width=70)
        trv_list_produtos.column("iva", width=70)
        trv_list_produtos.column("stock", width=70)
        trv_list_produtos.column("valor_stock", width=100)

        # Posicionando os widgets na tela
        order_by_label.pack()
        order_by_combo.pack()
        title_label.pack(expand=True)
        trv_list_produtos.pack(expand=True)
        btn_delete.pack(expand=True)
        btn_update.pack(expand=True)

        # Atualizar a lista de produtos inicial
        self.update_product_list(trv_list_produtos)

    def update_product_list(self, tree):
        # Limpar a árvore antes de recarregar os dados
        tree.delete(*tree.get_children())

        # Definir a coluna de ordenação
        order_column = "codigo" if self.order_by.get() == "codigo" else "iva"

        if order_column == "iva":
            # Se ordenar por IVA, abrir uma nova janela para selecionar o IVA desejado
            self.open_iva_selection_window(tree)
        else:
            # Executar a consulta ao banco de dados sem filtrar por IVA
            self.execute_product_query(tree, f"SELECT * FROM {co.TABLE_NAME} ORDER BY {order_column}")

    def open_iva_selection_window(self, tree):
        iva_window = IvaSelectionWindow(self, tree)

    def execute_product_query(self, tree, sql):
        co.cursor.execute(sql)
        produtos = co.cursor.fetchall()

        # Preencher a árvore com os produtos
        for produto in produtos:
            valor_stock = produto[2] * produto[4]
            tree.insert("", END, text=produto[0], values=(produto[1], produto[2], produto[3], produto[4], valor_stock))

        co.con.commit()


class IvaSelectionWindow(Toplevel):
    def __init__(self, parent, tree):
        super().__init__(parent)
        self.geometry('200x100')
        self.title('Selecionar IVA')

        self.parent = parent
        self.tree = tree

        iva_label = Label(self, text="Valor do IVA:")
        self.iva_entry = Entry(self)
        iva_button = Button(self, text="Selecionar", command=self.filter_by_iva)

        iva_label.pack()
        self.iva_entry.pack()
        iva_button.pack()

    def filter_by_iva(self):
        iva_value = self.iva_entry.get()
        try:
            iva_value = float(iva_value)
            sql = f"SELECT * FROM {co.TABLE_NAME} WHERE iva = {iva_value}"
            self.parent.execute_product_query(self.tree, sql)
            self.destroy()
        except ValueError:
            messagebox.showwarning("Aviso", "Por favor, insira um valor numérico válido para o IVA (use ponto para casas decimais).")


# class para atualizar os produtos
class update_produto_form(Toplevel):  
    def __init__(self, produto_id):
        super().__init__()
        self.geometry('400x300')
        self.title('Atualizar Produto')
        
        self.my_name_label = Label(self, text="Nome")
        self.my_name_text = Entry(self, width=62)
        self.my_preco_base_label = Label(self, text="Preco")
        self.my_preco_base_text = Entry(self, width=62)
        self.my_iva_label = Label(self, text="Iva")
        self.my_iva_text = Entry(self, width=62)
        self.my_stock_label = Label(self, text="Stock")
        self.my_stock_text = Entry(self, width=62)
        self.btn_update = Button(self, text="Atualizar produto", width=21, padx= 10, pady=5, command=lambda: update_selected_product(produto_id, self.my_name_text, self.my_preco_base_text, self.my_iva_text, self.my_stock_text))
        self.btn_cancel = Button(self, text="Cancelar", width=21, padx= 10, pady=5, command=self.destroy)

        self.my_name_label.grid(row=0, column=0, padx=(10,0), sticky="W")
        self.my_name_text.grid(row=1, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        self.my_preco_base_label.grid(row=3, column=0, padx=(10,0), sticky="W")
        self.my_preco_base_text.grid(row=4, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        self.my_iva_label.grid(row=5, column=0, padx=(10,0), sticky="W")
        self.my_iva_text.grid(row=6, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        self.my_stock_label.grid(row=7, column=0, padx=(10,0), sticky="W")
        self.my_stock_text.grid(row=8, column=0, columnspan=2, padx=(10,0), pady=(0,10))
        self.btn_update.grid(row=9, column=0, padx=(10,0), pady=(20,10))
        self.btn_cancel.grid(row=9, column=1, padx=(10,0), pady=(20,10))



def update_selected_product(produto_id, my_name_text, my_preco_base_text, my_iva_text, my_stock_text):
    co.cursor.execute(f"UPDATE {co.TABLE_NAME} SET nome = ?, preco_base = ?, iva = ?, stock = ? WHERE codigo = ?", (my_name_text.get(), my_preco_base_text.get(), my_iva_text.get(), my_stock_text.get(), produto_id))
    messagebox.showinfo("Sucesso", "Produto atualizado com sucesso")
    co.con.commit()
    write_log("Produto atualizado", produto_id)


def check_stock():
    co.cursor.execute(f"SELECT nome, stock FROM {co.TABLE_NAME} WHERE stock < 5")
    produtos_baixo_stock = co.cursor.fetchall()
    if produtos_baixo_stock:
        mensagem = "Os seguintes produtos estão com stock abaixo de 5 unidades:\n"
        for produto in produtos_baixo_stock:
            mensagem += f"{produto[0]}: {produto[1]}\n"
        messagebox.showwarning("stock Baixo", mensagem)

root = tk.Tk()
root.withdraw()

check_stock()

