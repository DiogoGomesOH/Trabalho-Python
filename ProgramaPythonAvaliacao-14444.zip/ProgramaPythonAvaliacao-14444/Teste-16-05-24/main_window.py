from tkinter import *
from my_functions import exit_app, new_produto_form, produto_list_form
from my_classes import Produto

window = Tk()
window.geometry('620x400')
window.title("Menu principal")

btn_inserir_produto = Button(window, text="Inserir Produto", width=35, pady=25, font=("Consolas",16), command=new_produto_form)
btn_inserir_produto.pack(expand=True)

btn_ver_produto = Button(window, text="Ver, Apagar e Atualizar produto", width=35, pady=25, font=("Consolas",16), command=produto_list_form)
btn_ver_produto.pack(expand=True)

btn_sair_programa = Button(window, text="Sair do Programa", width=35, pady=25, font=("Consolas",16), command=lambda: exit_app('window'))
btn_sair_programa.pack(expand=True)

window.mainloop()

