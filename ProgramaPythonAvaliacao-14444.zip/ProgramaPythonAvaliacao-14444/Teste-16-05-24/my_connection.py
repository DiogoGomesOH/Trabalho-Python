import sqlite3
from pathlib import Path 


ROOT_DIR = Path(__file__).parent
DB_NAME = "productmanagement.sqlite3"
DB_FILE = ROOT_DIR / DB_NAME
TABLE_NAME = "produtos"
con = sqlite3.connect(DB_FILE)
#Variavel que vai executar todas as operacoes na BD
cursor = con.cursor()


cursor.execute(
  f'CREATE TABLE IF NOT EXISTS {TABLE_NAME}'
  '('
      'codigo INTEGER PRIMARY KEY AUTOINCREMENT,'
      'nome TEXT,'
      'preco_base REAL,'
      'iva REAL,'
      'stock INTEGER'
  ')'
)

# Commit e fechamento da conexão
con.commit()
# con.close()